
class API{
  static const  apiUrl = 'https://jsonplaceholder.typicode.com/posts';
}